﻿namespace JeremyMProject_4
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lblGame = new Label();
            txtQuantity = new TextBox();
            lblQuantity = new Label();
            lstOutput = new ListBox();
            btnCalc = new Button();
            btnClear = new Button();
            btnQuit = new Button();
            lblPrice = new Label();
            txtPrice = new TextBox();
            SuspendLayout();
            // 
            // lblGame
            // 
            lblGame.AutoSize = true;
            lblGame.Font = new Font("Segoe UI Symbol", 21.75F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            lblGame.ForeColor = Color.Crimson;
            lblGame.Location = new Point(298, 20);
            lblGame.Name = "lblGame";
            lblGame.Size = new Size(184, 40);
            lblGame.TabIndex = 0;
            lblGame.Text = "Video Game";
            lblGame.TextAlign = ContentAlignment.TopCenter;
            lblGame.Click += txtGame_Click;
            // 
            // txtQuantity
            // 
            txtQuantity.Location = new Point(357, 111);
            txtQuantity.Name = "txtQuantity";
            txtQuantity.Size = new Size(81, 23);
            txtQuantity.TabIndex = 4;
            txtQuantity.TextChanged += txtQuantity_TextChanged;
            // 
            // lblQuantity
            // 
            lblQuantity.AutoSize = true;
            lblQuantity.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblQuantity.ForeColor = Color.Black;
            lblQuantity.Location = new Point(249, 111);
            lblQuantity.Name = "lblQuantity";
            lblQuantity.Size = new Size(102, 19);
            lblQuantity.TabIndex = 3;
            lblQuantity.Text = "Quantity (#):";
            // 
            // lstOutput
            // 
            lstOutput.FormattingEnabled = true;
            lstOutput.ItemHeight = 15;
            lstOutput.Location = new Point(85, 140);
            lstOutput.Name = "lstOutput";
            lstOutput.Size = new Size(622, 214);
            lstOutput.TabIndex = 5;
            lstOutput.TabStop = false;
            lstOutput.SelectedIndexChanged += lstOutput_SelectedIndexChanged;
            // 
            // btnCalc
            // 
            btnCalc.ForeColor = Color.Black;
            btnCalc.Location = new Point(85, 360);
            btnCalc.Name = "btnCalc";
            btnCalc.Size = new Size(116, 31);
            btnCalc.TabIndex = 6;
            btnCalc.Text = "&Total Cost";
            btnCalc.UseVisualStyleBackColor = true;
            btnCalc.Click += button1_Click;
            // 
            // btnClear
            // 
            btnClear.ForeColor = Color.Black;
            btnClear.Location = new Point(333, 360);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(118, 31);
            btnClear.TabIndex = 7;
            btnClear.Text = "&Clear";
            btnClear.UseVisualStyleBackColor = true;
            btnClear.Click += btnClear_Click;
            // 
            // btnQuit
            // 
            btnQuit.ForeColor = Color.Black;
            btnQuit.Location = new Point(606, 360);
            btnQuit.Name = "btnQuit";
            btnQuit.Size = new Size(101, 31);
            btnQuit.TabIndex = 8;
            btnQuit.Text = "&Quit";
            btnQuit.UseVisualStyleBackColor = true;
            btnQuit.Click += btnQuit_Click;
            // 
            // lblPrice
            // 
            lblPrice.AutoSize = true;
            lblPrice.BackColor = Color.Transparent;
            lblPrice.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblPrice.ForeColor = Color.Black;
            lblPrice.Location = new Point(274, 75);
            lblPrice.Name = "lblPrice";
            lblPrice.Size = new Size(77, 19);
            lblPrice.TabIndex = 1;
            lblPrice.Text = "Price ($):";
            // 
            // txtPrice
            // 
            txtPrice.Location = new Point(357, 75);
            txtPrice.Name = "txtPrice";
            txtPrice.Size = new Size(81, 23);
            txtPrice.TabIndex = 2;
            txtPrice.TextChanged += txtPrice_TextChanged;
            txtPrice.Enter += txtPrice_Enter;
            txtPrice.Leave += txtPrice_Leave;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.BurlyWood;
            ClientSize = new Size(800, 450);
            Controls.Add(txtPrice);
            Controls.Add(lblPrice);
            Controls.Add(btnQuit);
            Controls.Add(btnClear);
            Controls.Add(btnCalc);
            Controls.Add(lstOutput);
            Controls.Add(lblQuantity);
            Controls.Add(txtQuantity);
            Controls.Add(lblGame);
            ForeColor = Color.DarkRed;
            Name = "Form1";
            Text = "Game";
            TopMost = true;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label lblGame;
        private TextBox txtQuantity;
        private Label lblQuantity;
        private ListBox lstOutput;
        private Button btnCalc;
        private Button btnClear;
        private Button btnQuit;
        private Label lblPrice;
        private TextBox txtPrice;
    }
}
