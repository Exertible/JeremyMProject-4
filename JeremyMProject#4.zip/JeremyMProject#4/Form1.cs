namespace JeremyMProject_4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            btnCalc.Focus();

            // variables
            double GamePrice, totalGamePrice;
            int GameQuantity;
            bool PriceValid, QuantityValid;

            //input
            //parse
            // GamePrice = double.Parse(txtPrice.Text);
            // GameQuantity = int.Parse(txtQuantity.Text);
            PriceValid = double.TryParse(txtPrice.Text, out GamePrice);
            QuantityValid = int.TryParse(txtQuantity.Text, out GameQuantity);
            if (PriceValid & QuantityValid)
            {
                //processing
                totalGamePrice = GamePrice * GameQuantity;

                //output
                lstOutput.Items.Add("Your total price is " + totalGamePrice.ToString("C2"));
            }
            else
            {
                if (!PriceValid)
                    lstOutput.Items.Add("Enter a numeric number for the price");
                if (!QuantityValid)
                    lstOutput.Items.Add("Enter a whole number for quantity");
            }
            
        }

        private void txtGame_Click(object sender, EventArgs e)
        {

        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtPrice.Clear();
            txtQuantity.Clear();
            lstOutput.Items.Clear();
            txtPrice.Focus();
            txtQuantity.Focus();
        }

        private void btnQuit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lstOutput_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtPrice_Enter(object sender, EventArgs e)
        {
            txtPrice.BackColor = Color.White;
        }

        private void txtPrice_Leave(object sender, EventArgs e)
        {
            txtPrice.BackColor = Color.White;
        }

        private void txtPrice_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtGameName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
